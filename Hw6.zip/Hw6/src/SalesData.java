import java.io.FileReader;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class SalesData
{
	// Instance Variable
	private ArrayList<SalesRecord> records; // collection for data storage
	
	// Constructor
	public SalesData()
	{
		records = new ArrayList<SalesRecord>(); // collection for data storage
	}

	// ----------------DATA STORAGE METHODS-------------------------------------
	// Local method that reads the file in the file path,
	// creates SalesModel objects and adds them to the records
	public ArrayList<SalesRecord> loadDataFromFile(String filePath) // loading data from csv file
	{
		try
		{
			Scanner scanner = new Scanner(new FileReader(filePath));
			String line;
			SalesRecord record;

			scanner.nextLine(); // skipped reading the 1st line of the file
			System.out.println("\n\nNote1: Started the file reading process");
			while (scanner.hasNextLine())
			{
				line = scanner.nextLine(); // get the line
				String[] results = line.split(","); // split on the ,
				String date = results[0];
				YearMonth parsedDate= YearMonth.parse(date, DateTimeFormatter.ofPattern("LLL-yy"));
				Integer sales = Integer.parseInt(results[1]); // parse the results
				record = new SalesRecord(parsedDate, sales); // creating a record
				records.add(record); // add the record
			}
			System.out.println("Note2: Read a total of " + records.size() + " rows from the file");
			System.out.println("Note3: Finished the file reading process");
			scanner.close();
		} catch (Exception e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		return records;
	}
	
	// ----------------DATA PROCESSING METHODS-------------------------------------
	// Stream function to calculate the max sales
	public SalesRecord getMax()
	{
		SalesRecord maxValue  = records.stream().max(Comparator.comparingInt(SalesRecord::getSales)).get();
		return maxValue;
	}

	// Stream function to calculate the min sales
	public SalesRecord getMin()
	{
		SalesRecord minValue  = records.stream().min(Comparator.comparingInt(SalesRecord::getSales)).get();
		return minValue;
	}

	// Stream functions to filter entries by a year and aggregate all the sales
			
	public Integer getYearlySales(Integer passedYear)
	{
		Integer yearlySales = 0; // accumulator variable initialized to zero
		
		for (SalesRecord element: records) // iterating through the records array
		{
			if(element.getYearMonth().getYear() == passedYear) // checking for specific array elements of a year
			{
				yearlySales = yearlySales + element.getSales(); // updating the accumulator variable
			}
		}
		return yearlySales; // returning the updated accumulator variable
	}
}







