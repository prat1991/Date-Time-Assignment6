import java.time.YearMonth;

public class SalesRecord
{
	//Instance Variables
	private YearMonth yearMonth;
	private Integer sales;
	
	//Constructor
	public SalesRecord(YearMonth yearMonth, Integer sales)
	{
		this.yearMonth=yearMonth; // updating the instance variable
		this.sales=sales; // updating the instance variable
	}
	
	//Getter & Setter Methods 
	public YearMonth getYearMonth()
	{
		return yearMonth;  // getting the state of the instance variable
	}

	public void setYearMonth(YearMonth yearMonth)
	{
		this.yearMonth = yearMonth; //setting the state of the instance variable
	}

	public Integer getSales()
	{
		return sales; //getting the state of the instance variable
	}

	public void setSales(Integer sales)
	{
		this.sales = sales; //setting the state of the instance variable
	}
	
	//Specified so that salesData1.getMax() and salesData1.getMax()
	// dont display the objects memory location by the actual objects data
	@Override
	public String toString()
	{
		return "Object [YearMonth: " + yearMonth + ", " + "Sales: " + sales + " ]";
	}
}



